<?php
$title = "Checkout | Online Catering System";
    include('./include/header.php')
?>

<section class="py-5">
        <div class="container py-5">
            <div class="row mx-auto">
                <div class="col">
                    <div data-reflow-type="shopping-cart">HELLO WORLD</div>
                </div>
            </div>
        </div>
    </section>
<?php
    include('./include/footer.php')
?>