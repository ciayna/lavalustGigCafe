<?php 
 header("LOCATION:../")
?>

<h1>Oops you are on wrong Page (redirect you on back)</h1>